package com.ictkerala.scripts;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ictkerala.base.BaseClass;
import com.ictkerala.constants.AutomationConstants;
import com.ictkerala.pages.AddEmployeePage;
import com.ictkerala.pages.HomePage;
import com.ictkerala.pages.ListEmployeePage;
import com.ictkerala.pages.LoginPage;


public class ListEmployeeTest extends BaseClass {
	

	LoginPage objLogin;
	HomePage objHome;
	AddEmployeePage objAdd;
	ListEmployeePage objList;
	
	
	
	@BeforeMethod
	public void startUp() throws Exception {
		
		initialization();
		objLogin=new LoginPage(getDriver());
		objHome=new HomePage(getDriver());
		objAdd=new AddEmployeePage(getDriver());
		objList=new ListEmployeePage(getDriver());
		objLogin.setUname();
		objLogin.setPassword();
		objLogin.clickLogin();
		objHome.openListEmployee();
	}
	
	@AfterMethod
	public void tearDown() {
		getDriver().quit();
	}
	
//	@Test(priority=1)
//	public void verifyListView() {	
//		int actNum=objList.getListHeading();
//		Assert.assertEquals(AutomationConstants.expColNum,actNum);
//	}
	
	@Test(priority=2)
	public void verifyAdd(){
		String actTitle=objList.clickAdd();
		Assert.assertEquals(AutomationConstants.expAddEmpTitle,actTitle );
	}
	@Test(priority=3)
	public void verifyEdit() {
		String actTitle=objList.clickEdit();
		Assert.assertEquals(AutomationConstants.expAddEmpTitle, actTitle);
	}
	@Test(priority=4)
	public void verifyDelete() {
		String actMsg=objList.clickDelete();
		Assert.assertEquals(AutomationConstants.expMsg, actMsg);
	}

}
