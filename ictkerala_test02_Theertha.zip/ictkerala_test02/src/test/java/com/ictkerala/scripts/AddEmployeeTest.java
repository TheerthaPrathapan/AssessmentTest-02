package com.ictkerala.scripts;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.ictkerala.base.BaseClass;
import com.ictkerala.constants.AutomationConstants;
import com.ictkerala.pages.AddEmployeePage;
import com.ictkerala.pages.HomePage;
import com.ictkerala.pages.ListEmployeePage;
import com.ictkerala.pages.LoginPage;

public class AddEmployeeTest extends BaseClass {
	
	LoginPage objLogin;
	HomePage objHome;
	AddEmployeePage objAdd;
	ListEmployeePage objList;
	
	
	
	@BeforeMethod
	public void startUp() throws Exception {
		
		initialization();
		objLogin=new LoginPage(getDriver());
		objHome=new HomePage(getDriver());
		objAdd=new AddEmployeePage(getDriver());
		objList=new ListEmployeePage(getDriver());
		objLogin.setUname();
		objLogin.setPassword();
		objLogin.clickLogin();
		
	}
	@AfterMethod
	public void tearDown() {
		getDriver().quit();
	}
	@Test(priority=1)
	public void verifyValidSubmit() throws Exception {
		
		objHome.openAddEmployee();
		objAdd.setName();
		objAdd.setId();
		objAdd.setPwd();
		objAdd.setconfirmPwd();
		objAdd.setEmail();
		objAdd.setMob();
		objAdd.setDesignation();
		objAdd.setReport();
		objAdd.setMemberof();
		objAdd.setType();
		objAdd.setAddress();
		objAdd.clickSubmitBtn();
//		objHome.openAddEmployee();
//		objAdd.setName();
//		objAdd.setPassword();
//		objAdd.setEmail();
//		objAdd.selectDesignation();
//		objAdd.selectReporting();
//		objAdd.selectMemberOf();
//		objAdd.setEmpId();
//		objAdd.setConfirmPwd();
//		objAdd.setNumber();
//		objAdd.selectEmpType();
//		objAdd.selectRepStaff();
//		objAdd.setAddress();
//		objAdd.clickSubmit();
		String actTitle=objList.getEmpHeading();
		AssertJUnit.assertEquals(AutomationConstants.expListEmpTitle,actTitle);
		
	}
	@Test(priority=2)
	public void verifyReset() throws Exception {
		
		objHome.openAddEmployee();
		objAdd.setName();
		objAdd.setId();
		objAdd.setPwd();
		objAdd.setconfirmPwd();
		objAdd.setEmail();
		objAdd.setMob();
		objAdd.setDesignation();
		objAdd.setReport();
		objAdd.setMemberof();
		objAdd.setType();
		objAdd.setAddress();
		String actName=objAdd.clickReset();
		AssertJUnit.assertEquals(objAdd.getName(),actName);
	}
	
	@Test(priority=3)
	public void verifyBack() throws Exception {
		String expUrl=getDriver().getCurrentUrl();
		objHome.openAddEmployee();		
		String actUrl=objAdd.clickBack();
		AssertJUnit.assertEquals(expUrl,actUrl);
		
	}
	@Test(priority=4)
	public void verifyNullSubmit() throws Exception {
		objHome.openAddEmployee();
		objAdd.clickSubmitBtn();	
		Assert.assertTrue(objAdd.getValidSummary());
		
	}
	

}
