package com.ictkerala.pages;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ictkerala.base.BaseClass;
import com.ictkerala.constants.AutomationConstants;
import com.ictkerala.utilities.PageUtility;

public class LoginPage extends BaseClass{
	WebDriver driver;
	
	@FindBy(id="txtUsername")
	private WebElement unameBox;
	
	@FindBy(id="txtPassword")
	private WebElement pwdBox;
	
	@FindBy(id="btnSubmit")
	private WebElement loginBtn;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);	
	}
	
	public void setUname() {
		PageUtility.sendInput(unameBox, AutomationConstants.uname);	
	}
	public void setPassword() {
		PageUtility.sendInput(pwdBox, AutomationConstants.pwd);
	}
	public void clickLogin() {
		PageUtility.clickBtn(driver, loginBtn);
	}

}
