package com.ictkerala.pages;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ictkerala.utilities.PageUtility;


public class HomePage {
	

	WebDriver driver;
	
	@FindBy(linkText="Employee")
	private WebElement EmployeeLink;
	
	@FindBy(linkText="Add Employee")
	private WebElement addEmpLink;
	
	@FindBy(linkText="List Employee")
	private WebElement listEmpLink;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void openAddEmployee() {
		PageUtility.hoverElement(driver,addEmpLink);
		PageUtility.clickEvent(addEmpLink);
		
	}
	public void openListEmployee() {
		PageUtility.hoverElement(driver,listEmpLink);
		PageUtility.clickEvent(listEmpLink);
	}

	

}
