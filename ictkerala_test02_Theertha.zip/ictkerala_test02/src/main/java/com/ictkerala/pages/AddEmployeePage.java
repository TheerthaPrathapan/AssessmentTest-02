package com.ictkerala.pages;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ictkerala.constants.AutomationConstants;
import com.ictkerala.utilities.PageUtility;

public class AddEmployeePage {
	
	WebDriver driver;
	@FindBy(id="ContentPlaceHolder1_lblTitle")
	private WebElement title;
	

	@FindBy(id="ContentPlaceHolder1_txtName")
	private WebElement nameBox;
	
	@FindBy(id="ContentPlaceHolder1_txtEmployeeId")
	private WebElement empIdBox;
	
	@FindBy(id="ContentPlaceHolder1_txtPassword")
	private WebElement pwdBox;
	
	@FindBy(id="ContentPlaceHolder1_txtConfirmPassword")
	private WebElement confirmPwdBox;
	
	@FindBy(id="ContentPlaceHolder1_txtEmail")
	private WebElement emailBox;
	
	@FindBy(id="ContentPlaceHolder1_txtMobileNumber")
	private WebElement phnNumBox;
	
	@FindBy(id="ContentPlaceHolder1_drpDesignation")
	private WebElement designationBox;
	
	@FindBy(id="ContentPlaceHolder1_drpEmployeeType")
	private WebElement empTypeBox;
	
	@FindBy(id="ContentPlaceHolder1_drpReportingTo")
	private WebElement reportToBox;
	
	@FindBy(id="ContentPlaceHolder1_drpGroup")
	private WebElement memberBox;
	
	@FindBy(id="ContentPlaceHolder1_txtAddress")
	private WebElement addressBox;
	
	@FindBy(id="ContentPlaceHolder1_btnSubmit")
	private WebElement submitBtn;
	
	@FindBy(id="Reset")
	private WebElement resetBtn;
	
	@FindBy(id="ContentPlaceHolder1_btnBack")
	private WebElement backBtn;

	@FindBy(id="ContentPlaceHolder1_ValidationSummary")
	private WebElement validSummary;
	
	
	public AddEmployeePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setName() {
		PageUtility.sendInput(nameBox, AutomationConstants.name);
	}
	public void setId() {
		PageUtility.sendInput(empIdBox, AutomationConstants.id);
	}
	public void setPwd() {
		PageUtility.sendInput(pwdBox,AutomationConstants.password );
	}
	public void setconfirmPwd() {
		PageUtility.sendInput(confirmPwdBox, AutomationConstants.confirmPwd);
	}
	public void setEmail() {
		PageUtility.sendInput(emailBox, AutomationConstants.email);
	}
	public void setMob() {
		PageUtility.sendInput(phnNumBox, AutomationConstants.mobNum);
	}	
	public void setDesignation() {
		PageUtility.select(designationBox, AutomationConstants.designation);
	}
	public void setType() {
		PageUtility.select(empTypeBox, AutomationConstants.empType);
	}
	public void setReport() {
		PageUtility.select(reportToBox, AutomationConstants.reportingTo);
	}
	public void setMemberof() {
		PageUtility.select(memberBox, AutomationConstants.memberOf);
	}
	public void setAddress() {
		PageUtility.sendInput(addressBox, AutomationConstants.address);
	}
	public void clickSubmitBtn() {
		PageUtility.clickBtn(driver, submitBtn);
	}
	
	public String clickReset() {
		
		PageUtility.clickEvent(resetBtn);
		return PageUtility.readText(nameBox);
	}
	public String clickBack() {
		
		PageUtility.clickEvent(backBtn);
		String actUrl=driver.getCurrentUrl();
		return actUrl;
	}
	public String getTitle() {
		
		return PageUtility.readText(title);
	}
	public String getName() {
		return PageUtility.readText(nameBox);
	}
	public boolean getValidSummary() {
		boolean bool=PageUtility.display(validSummary);
		return bool;
		
	}
	
}
