package com.ictkerala.pages;

import java.util.List;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ictkerala.utilities.PageUtility;
import com.ictkerala.utilities.WaitUtility;

public class ListEmployeePage {
	WebDriver driver;
	
//	@FindBy(xpath="//span[@style=\"list-style-type: square;\"]")
//	private WebElement EmpText;
//	
//	@FindBy(xpath="//th[1]")
//	private WebElement sNoText;
//	
//	
//	public ListEmployeePage(WebDriver driver) {
//		this.driver=driver;
//		PageFactory.initElements(driver,this);
//	}
//	public String extractEmp() {
//		 String actText= PageUtility.readText(EmpText);
//		 return actText;
//	 }
//	
//	public String extractSNo() {
//		String actText= PageUtility.readText(sNoText);
//		return actText;
//	}
	@FindBy(xpath="//span[text()=\"Employees\"]")
	private WebElement empHeading;
	
	@FindBy(xpath="//table[@id=\"ContentPlaceHolder1_gvList\"]/tbody/tr/th")
	private List<WebElement> listHeading;
	
	@FindBy(id="addButton")
	private WebElement addBtn;
	
	@FindBy(linkText="Edit")
	private WebElement editBtn;
	
	@FindBy(linkText="Delete")
	private WebElement deleteBtn;
	
	@FindBy(id="ContentPlaceHolder1_lblMsg")
	private WebElement dltMsg;
	
	public ListEmployeePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public String getEmpHeading() {
		WaitUtility.waitForElement(driver, empHeading);
		return PageUtility.readText(empHeading);
		
	}
	public int getListHeading() {
		
		return listHeading.size();
	}
	public String clickAdd() {
		AddEmployeePage objAdd=new AddEmployeePage(driver);
		PageUtility.clickEvent(addBtn);
		return objAdd.getTitle();
	}
	public String clickEdit() {
		AddEmployeePage objAdd=new AddEmployeePage(driver);
		PageUtility.clickEvent(editBtn);
		return objAdd.getTitle();
	}
	public String clickDelete() {
		PageUtility.clickEvent(deleteBtn);
		PageUtility.handleAlert(driver);
		return dltMsg.getText();
	}
	

}
