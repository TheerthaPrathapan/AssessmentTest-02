package com.ictkerala.constants;

public class AutomationConstants {
	
public static String uname = "practice.swtesting@gmail.com";
	
	public static String pwd ="123";	
	
	public static String expText ="Logout";	
	public static String name="Theertha Prathapan";
	public static String id="51234";
	public static String password ="theertha@123";
	public static String confirmPwd ="theertha@123";
	public static String mobNum="9061432057";
	public static String email ="theerthap@gmail.com";
	public static String designation="Knowledge Officer";
	public static String empType="Permanant";
	public static String reportingTo="Bincy";
	public static String memberOf="Team10da9";
	public static String address="Devatheertha,Kannur,Kerala";
	public static String exptdText="Employees";
	public static String expectedText="SNo";
	
	public static String expListEmpTitle="Employees";
	public static String expAddEmpTitle="Add";
	public static String expName="Theertha Prathapan";
	public static String expDesignation="Knowledge Officer";
	public static String expMsg="Deleted the employee successfully!!!";
	

}
