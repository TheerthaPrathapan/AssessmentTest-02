package com.ictkerala.utilities;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class PageUtility {
	
public static void sendInput(WebElement element,String input) {
		
		element.clear();
		element.sendKeys(input);
		
	}
	public static void clickBtn(WebDriver driver,WebElement element) {
		WaitUtility.waitForElementToBeClickable(driver, element);;
		element.click();
		
	}
	public static void clickEvent(WebElement element){

	element.click();
	}
	
	public static void scrollTillElement(WebDriver driver,WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",element);
	}
	
	public static String readText(WebElement element) {
		return element.getText();
		
	}

	public static boolean display(WebElement element) {
		return element.isDisplayed();	
	}
	
	public static void selectCheckBox(WebElement element) {
		if(!element.isSelected()) {
			element.click();
		}
	}
	public static void actionClick(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).click().build().perform();
	}
	public static void handleAlert(WebDriver driver) {
		Alert alert = driver.switchTo().alert();
		alert.accept();	
	}
	
	public static void hoverElement(WebDriver driver,WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
	}
	

	public static void select(WebElement ele,String status) {
		Select s=new Select(ele);
		s.selectByVisibleText(status);
	}


}
